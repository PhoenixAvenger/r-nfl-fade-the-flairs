link = document.createElement( "link" );
link.href = "https://raw.githubusercontent.com/PhoenixAvenger/r-nfl-fade-the-flairs/master/fadetheflairs.css"
link.type = "text/css";
link.rel = "stylesheet";
link.media = "screen,print";

document.getElementsByTagName( "head" )[0].appendChild( link );