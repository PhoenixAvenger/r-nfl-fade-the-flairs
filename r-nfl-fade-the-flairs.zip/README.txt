Created By: PhoenixAvenger
On: December 6th 2015

This chrome plugin will fade the flairs for teams that have been eliminated from the playoffs.